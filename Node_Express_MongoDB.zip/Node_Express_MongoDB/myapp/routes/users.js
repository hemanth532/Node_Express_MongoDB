var express = require('express');
var router = express.Router();
var MongoClient = require('mongodb').MongoClient;
var mongodbUrl = require('./configdetails/mongoDbDetails');
function connectMongo(){
  return new Promise(function(resolve, reject){
      resolve( MongoClient.connect(mongodbUrl.mongoDbUrl, mongodbUrl.options));
  })
}
/* GET users listing. */
router.get('/', function(req, res, next) {
  return new Promise(async function(resolve, reject){
  var dbConnection = await connectMongo().catch(err => {
    console.log(err);
    res.send(err);
  });
  var db = dbConnection.db('Ranjan');
  var collection = db.collection('Ranjan_Collection1');
  var myobj = { name: "Company Inc", address: "Highway 37" };
  collection.insertOne(myobj, function(err, items) {
    if(err){
      res.send(err);
    } 
    else{
    res.send(items); 
    }
  });
});
});

module.exports = router;
